package com.project2;

public class LeaveException extends Exception {
	LeaveException(){}
	LeaveException(String error){
		super(error);
	}
	
}

