package com.project2;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;





public class LeaveDAO {
	static List<LeaveDetails> LeaveDetailsList;
	static {
		LeaveDetailsList=new ArrayList<>();
	}
	public String readLeaveFileDao() throws IOException, ClassNotFoundException {
		FileInputStream fin = new FileInputStream("C:/filess/leaves.txt");
		ObjectInputStream objin = new ObjectInputStream(fin);
		LeaveDetailsList = (List<LeaveDetails>)objin.readObject();
		return "Data Retrieved from File Successfully...";
	}
	public String writeLeaveFileDao() throws IOException {
		FileOutputStream fout = new FileOutputStream("C:/filess/leaves.txt");
		ObjectOutputStream objout = new ObjectOutputStream(fout);
		objout.writeObject(LeaveDetailsList);
		objout.close();
		fout.close();
		return "Data Stored in File Successfully...";
	}

	
	public String AddLeaveDao(LeaveDetails ld)
	{
		LeaveDetailsList.add(ld);
		return "Leave Details Successfully Added";
	}
	
	public List<LeaveDetails> ShowLeaveDetailsDao()
	{
		return LeaveDetailsList;
	}
	
	public String deleteLeaveDao(int id)
	{
		for (LeaveDetails leaveDetails : LeaveDetailsList) 
		{
			if(leaveDetails.getLeaveId()==id)
			{
				LeaveDetailsList.remove(leaveDetails);
				return "deleted Successfully";
			}
		}
		return "No record Found";
	}
	
	public LeaveDetails searchLeaveDao(int id)
	{
		for (LeaveDetails leaveDetails : LeaveDetailsList) 
		{
			if(leaveDetails.getLeaveId()==id)
			{
				return leaveDetails;
			}
		}
		return null;
	}
	
	public String updatedetails(LeaveDetails ob)
	{
		for (LeaveDetails leaveDetails : LeaveDetailsList) {
			if(leaveDetails.getLeaveId()==ob.getLeaveId())
			{
				leaveDetails.setLeaveStartDate(ob.getLeaveStartDate());
				leaveDetails.setLeaveEndDate(ob.getLeaveEndDate());
				leaveDetails.setEmpId(ob.getEmpId());
				leaveDetails.setNoOfDays(ob.getNoOfDays());
				leaveDetails.setLeaveAppliedOn(ob.getLeaveAppliedOn());
				leaveDetails.setLeaveReason(ob.getLeaveReason());
				return "Successfully updated";
			}
		}
		return "No record Found";
	}

}
