package com.Prgrm;

public class perfect {
			
		public long show(long num) {
			long sum=0;    
			for(int i=1; i <= num/2; i++)  
			{  
			if(num % i == 0)  
			{  
			sum=sum + i;
			
			}
			}
			return sum;
					  
		}
	public static void main(String[] args) {
		
		long number=10,s ;   
		perfect obj =new perfect();
		s=obj.show(number);
		
		if(s==number)  
		System.out.println(number+" is a perfect number");  
		else  
		System.out.println(number+" is not a perfect number");   
	
	}
		
}
