package com.Prgrm;

public class currentbill {
	public void show(int units) {
		double billamount=0;
		if(units<=100) {
			billamount= units*1.2;
		}
		else if( units>100 && units<=150 ) {
			billamount=(100*1.2)+((units-100)*1.5);
		}
		else if(units>150 && units<=200) {
			billamount=(100*1.2)+((50)*1.5)+((units-150)*2);
		}
		else if(units>200 && units<=250) {
			billamount=(100*1.2)+((50)*1.5)+((50)*2)+((units-200)*2.5);
		}
		else if(units>200 && units<=250) {
			billamount=(100*1.2)+((50)*1.5)+((50)*2)+((units-200)*2.5);
		}else {
			billamount=(100*1.2)+((50)*1.5)+((50)*2)+((50)*2.5)+((units-250)*3);
		}
			
			System.out.println("the bill amount is "+billamount);
		}
	
	
	public static void main(String[] args) {
		int units= 400;
		currentbill obj= new currentbill();
		obj.show(units);
	}

}
