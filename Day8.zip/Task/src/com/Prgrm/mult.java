package com.Prgrm;

import java.math.BigInteger;
import java.util.Scanner;

public class mult {
	public static void main(String[] args) {
	    String str1="1234567890987654321345678996543212345678954323456789";
	    String str2="5789676543234567890987654321345678908543213425678974";
	       BigInteger a= new BigInteger(str1);
	       BigInteger b=new BigInteger(str2);
	       BigInteger mult;
	       mult=a.multiply(b);
	       System.out.println("Product of two numbers is "+mult);
	}

}
