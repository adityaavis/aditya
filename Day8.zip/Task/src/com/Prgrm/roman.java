package com.Prgrm;

public class roman {
	
		
	public static void introman(int n) {

        
        int[] values = {1000,900,500,400,100,90,50,40,10,9,5,4,1};
        String[] roman = {"M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I"};

        StringBuilder ro = new StringBuilder();

        for(int i=0;i<values.length;i++) {
            while(n >= values[i]) {
                n -= values[i];
                ro.append(roman[i]);
            }
        }
        System.out.println( "Roman: " + ro.toString());
        
    }

    public static void main(String[] args) {
        introman(25);
        introman(9999);
        
    }

}