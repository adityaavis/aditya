package com.Prgrm;

public class armstng {

    public static void main(String[] args) {

        int number1 = 1, originalNumber, remainder, result ,number2=200;
        while(number1<=number2)
        {

        originalNumber = number1;
        result=0;

        while (originalNumber != 0)
        {
            remainder = originalNumber % 10;
            result += Math.pow(remainder, 3);
            originalNumber /= 10;
        }

        if(result == number1)
            System.out.println(number1 + " is an Armstrong number.");
        
        number1++;
    }
    }
}